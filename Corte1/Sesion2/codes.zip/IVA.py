p=float(input('Ingrese el valor del cual quiere sustraer el IVA'))
t=p/(1+0.19)
r=p-t
print('El valor del producto es ' ,t, 'y el IVA añade' ,r,)