F=float(input('Ingrese temperatura en Fahrenheit'))
C=5/9*(F-32)
print('',F, 'grados Fahrenheit en centigrados es' ,C, 'grarods')