n=float(input('Ingrese la medida en pulgadas'))
r=n*25.4
print('',n, ' pulgadas en milimetros es' ,r,)